# ALAM Number Lookup
Android Java app (minimum Android 7.0). Your supplied portrait is used as the launcher icon and in the header.

## What works
- Enter an international phone number and select Search All.
- See country inferred from known dialing prefixes (not a GPS location).
- Open WhatsApp chat, Truecaller website, public Google searches for Facebook/Instagram, and installed imo/Telegram/Messenger/Viber apps.
- No contacts permission, tracking, scraping, hidden identity retrieval, or fabricated account matches.

## GitHub one-ZIP workflow
First time only, upload TWO files to repository root: `ALAM_Number_Lookup.zip` and `.github/workflows/build-apk.yml` (the latter is included inside the ZIP too, but GitHub cannot execute a workflow stored only inside a ZIP). Afterwards, replace only `ALAM_Number_Lookup.zip` and GitHub Actions will extract and build it. In Actions, download the `ALAM-Number-Lookup-APK` artifact after a successful build.

The ZIP contains the entire Android project at ZIP root. Do not upload or extract it into a nested folder. You can also extract the ZIP and open the project in Android Studio.

## Limits
Facebook/Instagram phone-number-to-profile lookup is not generally available. A public web search may return no result. Truecaller might require sign-in. Deep links depend on installed apps and app versions. No live location, NID, SIM-registration identity, or private account records can be discovered from a phone number.


ONE-ZIP USAGE: This ZIP contains the entire Android source and the GitHub Actions workflow.
For a brand-new repository, extract the ZIP and upload its contents to the repository root once (including the hidden .github directory). GitHub cannot execute a workflow that exists only inside a ZIP.
After that bootstrap, upload/replace ALAM_Number_Lookup.zip at repository root to trigger the existing workflow. The workflow extracts the ZIP and builds a debug APK.
The app provides platform links, not automatic cross-platform identity results.
