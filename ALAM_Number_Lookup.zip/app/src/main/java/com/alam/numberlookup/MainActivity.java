package com.alam.numberlookup;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;

public class MainActivity extends Activity {
    final int BG=Color.rgb(6,10,29), PANEL=Color.rgb(17,25,57), BLUE=Color.rgb(31,181,255), WHITE=Color.WHITE, MUTED=Color.rgb(170,188,219);
    LinearLayout root, results; EditText phone; String digits="";
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    GradientDrawable shape(int color,int radius,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    void add(LinearLayout p,View v,int top){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(top);p.addView(v,lp);}
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
      ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(18),dp(24),dp(18),dp(28));scroll.addView(root);setContentView(scroll);
      LinearLayout head=new LinearLayout(this);head.setOrientation(LinearLayout.HORIZONTAL);head.setGravity(Gravity.CENTER_VERTICAL);
      ImageView portrait=new ImageView(this);portrait.setImageResource(com.alam.numberlookup.R.drawable.alam_portrait);portrait.setScaleType(ImageView.ScaleType.CENTER_CROP);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(66),dp(66));ip.rightMargin=dp(12);head.addView(portrait,ip);
      LinearLayout title=new LinearLayout(this);title.setOrientation(1);title.addView(text("ALAM",30,WHITE,true));title.addView(text("NUMBER LOOKUP",16,BLUE,true));head.addView(title);add(root,head,0);
      add(root,text("Search public profiles and open supported apps",13,MUTED,false),12);
      phone=new EditText(this);phone.setSingleLine(true);phone.setTextColor(WHITE);phone.setHintTextColor(MUTED);phone.setTextSize(17);phone.setHint("+880 1XXXXXXXXX");phone.setInputType(InputType.TYPE_CLASS_PHONE);phone.setPadding(dp(18),dp(14),dp(18),dp(14));phone.setBackground(shape(PANEL,18,BLUE));add(root,phone,22);
      Button search=new Button(this);search.setText("⌕   SEARCH ALL");search.setTextColor(WHITE);search.setTextSize(17);search.setAllCaps(false);search.setBackground(shape(Color.rgb(75,48,206),18,BLUE));add(root,search,12);
      results=new LinearLayout(this);results.setOrientation(1);add(root,results,14);
      TextView disclaimer=text("Privacy: No hidden account data, live location, SIM owner ID, or private photos are retrieved. Results open the respective service for manual verification. Country is inferred from dialing code only.",12,MUTED,false);disclaimer.setPadding(dp(10),dp(16),dp(10),dp(8));add(root,disclaimer,10);
      search.setOnClickListener(v->runSearch());showEmpty();
    }
    void showEmpty(){results.removeAllViews();add(results,text("Enter a phone number to see available lookup options.",14,MUTED,false),12);}
    String normalized(){String n=phone.getText().toString().replaceAll("[^0-9]","");if(n.startsWith("00"))n=n.substring(2);if(n.startsWith("0")&&n.length()==11)n="88"+n;return n;}
    void runSearch(){digits=normalized();if(digits.length()<8||digits.length()>15){phone.setError("Enter a valid phone number with country code");return;}results.removeAllViews();
      String country=digits.startsWith("880")?"Bangladesh (+880)":digits.startsWith("39")?"Italy (+39)":digits.startsWith("91")?"India (+91)":digits.startsWith("1")?"North America (+1)":"Country not identified";
      TextView location=text("COUNTRY CODE: "+country+"\nLive location: Not available",14,WHITE,true);location.setPadding(dp(14),dp(14),dp(14),dp(14));location.setBackground(shape(PANEL,16,BLUE));add(results,location,8);
      card("WhatsApp","Open chat; profile visibility depends on privacy settings", "https://wa.me/"+digits,"WA",0xff23c866);
      card("Truecaller","Open caller ID lookup; name may be inaccurate", "https://www.truecaller.com/search/"+(digits.startsWith("880")?"bd":digits.startsWith("39")?"it":"")+"/"+digits,"TC",0xff1599ee);
      card("Facebook","Search public web results; number matching is not guaranteed", "https://www.google.com/search?q="+Uri.encode("site:facebook.com \""+digits+"\""),"f",0xff1877f2);
      card("imo","Open imo app; search the number manually", "imo://", "imo",0xff2489ff);
      card("Telegram","Open Telegram; contacts require app permissions", "tg://", "➤",0xff27a7e7);
      card("Instagram","Search public web mentions of the number", "https://www.google.com/search?q="+Uri.encode("site:instagram.com \""+digits+"\""),"IG",0xffd84aa4);
      card("Messenger","Open Messenger app", "fb-messenger://", "M",0xffa34af5);
      card("Viber","Open Viber app", "viber://", "V",0xff7950ba);
      card("Other public web results","Search indexed public pages only", "https://www.google.com/search?q="+Uri.encode("\""+digits+"\""),"⌕",BLUE);
    }
    void card(String name,String detail,String url,String logo,int color){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(12),dp(14),dp(10),dp(14));row.setBackground(shape(PANEL,17,0xff344b88));
      TextView icon=text(logo,logo.length()>2?13:20,WHITE,true);icon.setGravity(Gravity.CENTER);icon.setBackground(shape(color,13,0));LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams(dp(48),dp(48));ilp.rightMargin=dp(12);row.addView(icon,ilp);
      LinearLayout words=new LinearLayout(this);words.setOrientation(1);words.addView(text(name,17,WHITE,true));TextView d=text(detail,11,MUTED,false);d.setMaxLines(3);words.addView(d);row.addView(words,new LinearLayout.LayoutParams(0,-2,1));
      TextView arrow=text("↗",25,BLUE,true);arrow.setPadding(dp(9),0,0,0);row.addView(arrow);add(results,row,9);row.setOnClickListener(v->open(url,name));
    }
    void open(String url,String name){try{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(url));startActivity(i);}catch(Exception e){Toast.makeText(this,name+" app not installed or link unavailable",Toast.LENGTH_LONG).show();}}
}
